import os
from PIL import Image

data_dir="NORMAL/"
out_dir="data/"
img_size=128
if __name__ == "__main__":
    for file in os.listdir(data_dir + 'data/'):
        image = Image.open(data_dir + 'data/' + file)
        print(file)
        if image.size[0] != img_size or image.size[1] != img_size:
            image = image.resize((img_size,img_size))
        #if (image.mode != 'RGB'):
        #   image = image.convert("RGB")
        image.save(out_dir + 'data/' + file)
